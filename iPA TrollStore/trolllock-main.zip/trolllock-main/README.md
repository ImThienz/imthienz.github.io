<b>Icon TrollLock</b><p>
All icons are collected on the internet and developed by me.
<p>Now. Support TrollLock New Version : https://github.com/haxi0/TrollLock-Reborn
<p> You can follow me via social media link: <p>
<a href="https://twitter.com/duongduong0908">Twitter</a><p>
<p>Installation instructions are available here:<a href="https://twitter.com/duongduong0908/status/1609165453343232000?s=20&t=K6Ke6JmcfOqmoVBY8Rk4mQ">Tutorial</a>
